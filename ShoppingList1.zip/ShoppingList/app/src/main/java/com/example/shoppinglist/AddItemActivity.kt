package com.example.shoppinglist

import android.app.AlertDialog
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.shoppinglist.models.ShoppingItem

class AddItemActivity : AppCompatActivity() {

    // Компоненты для работы
    private lateinit var db: DatabaseHelper
    private lateinit var categorySpinner: Spinner
    private lateinit var nameInput: EditText
    private lateinit var priceInput: EditText
    private lateinit var categoryNames: Array<String>
    private lateinit var categoryIds: List<Int>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_item)

        // Инициализация
        db = DatabaseHelper(this)
        categorySpinner = findViewById(R.id.spinnerCategory)
        nameInput = findViewById(R.id.etItemName)
        priceInput = findViewById(R.id.etItemPrice)

        // Загругка категорий
        loadCategories()
        // Настройка кнопок
        findViewById<Button>(R.id.btnSave).setOnClickListener { saveItem() }
        findViewById<Button>(R.id.btnCancel).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnNewCategory).setOnClickListener { showNewCategoryDialog() }
    }

    // Загрузка категорий из БД и их отображение
    private fun loadCategories() {
        val categories = db.getCategories()
        categoryNames = categories.map { it.name }.toTypedArray()
        categoryIds = categories.map { it.id }
        // Адаптер
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categoryNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        categorySpinner.adapter = adapter
    }

    // Диалог для создания новой категории
    private fun showNewCategoryDialog() {
        val input = EditText(this).apply { hint = "Название категории" }

        AlertDialog.Builder(this)
            .setTitle("Новая категория")
            .setView(input)
            .setPositiveButton("Добавить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) {
                    db.addCategory(name)
                    loadCategories() // Перезагрузка категорий после добавления
                    Toast.makeText(this, "Категория добавлена", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
    // Сохранение товара в БД
    private fun saveItem() {
        val name = nameInput.text.toString().trim()
        if (name.isEmpty()) {
            Toast.makeText(this, "Введите название", Toast.LENGTH_SHORT).show()
            return
        }
        // Преобразование цены
        val price = priceInput.text.toString().toDoubleOrNull() ?: 0.0
        val categoryId = categoryIds[categorySpinner.selectedItemPosition]
        // Создание товара и сохранение в базу
        val item = ShoppingItem(0, categoryId, name, price, false)
        db.addItem(item)

        Toast.makeText(this, "Товар добавлен", Toast.LENGTH_SHORT).show()
        finish()
    }
}