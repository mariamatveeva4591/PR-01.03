package com.example.shoppinglist

import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.example.shoppinglist.models.Category
import com.example.shoppinglist.models.ShoppingItem
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.text.NumberFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // Компоненты для работы с данными UI
    private lateinit var db: DatabaseHelper
    private lateinit var container: LinearLayout
    private lateinit var totalText: TextView
    private lateinit var filterCheck: CheckBox
    private lateinit var budgetProgress: ProgressBar
    private lateinit var budgetInfo: TextView
    private lateinit var fabAdd: FloatingActionButton

    private val budget = 2000.0 // Фиксированный бюджет
    private val currency = NumberFormat.getCurrencyInstance(Locale("ru", "RU"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Инициализация компонентов
        db = DatabaseHelper(this)
        container = findViewById(R.id.llCategories)
        totalText = findViewById(R.id.tvTotalPrice)
        filterCheck = findViewById(R.id.cbShowOnlyNotPurchased)
        budgetProgress = findViewById(R.id.progressBudget)
        budgetInfo = findViewById(R.id.tvBudgetInfo)
        fabAdd = findViewById(R.id.btnAdd)

        budgetInfo.text = "Бюджет: ${currency.format(budget)}"
        // Обновление списка при изменении чукбокса
        fabAdd.setOnClickListener {
            startActivity(Intent(this, AddItemActivity::class.java))
        }

        filterCheck.setOnCheckedChangeListener { _, _ -> refreshList() }
        // Первоначальная загрузка списка
        refreshList()
    }
    // Обновление списка
    override fun onResume() {
        super.onResume()
        refreshList()
    }

    // Загрузка данных из БД
    private fun refreshList() {
        container.removeAllViews()
        val items = db.getItems(filterCheck.isChecked)
        var total = 0.0

        if (items.isEmpty()) {
            // Показываем сообщение, если нет товаров
            val emptyView = layoutInflater.inflate(R.layout.item_empty, null)
            container.addView(emptyView)
        } else {
            items.forEach { (category, itemList) ->
                val card = layoutInflater.inflate(R.layout.item_category, null)
                card.findViewById<TextView>(R.id.tvCategoryName).text = category.name

                val itemsContainer = card.findViewById<LinearLayout>(R.id.llItems)
                itemList.forEach { item ->
                    val row = createItemRow(item)
                    itemsContainer.addView(row)
                    if (item.isPurchased) total += item.price
                }

                container.addView(card)
            }
        }
        // Обновление итоговой суммы и прогресс-бара
        totalText.text = "Итого: ${currency.format(total)}"
        updateBudgetProgress(total)
    }
    // Содание карточки товара
    private fun createItemRow(item: ShoppingItem): LinearLayout {
        val row = layoutInflater.inflate(R.layout.item_shopping, null) as LinearLayout
        // Заполнение данных
        row.findViewById<TextView>(R.id.tvItemName).text = item.name
        row.findViewById<TextView>(R.id.tvItemPrice).text =
            if (item.price > 0) currency.format(item.price) else "—"

        val check = row.findViewById<CheckBox>(R.id.cbPurchased)
        check.isChecked = item.isPurchased
        check.setOnCheckedChangeListener { _, isChecked ->
            db.updateItem(item.id, isChecked)
            refreshList()
        }
        // Клик - редактирование
        row.setOnClickListener {
            showEditDialog(item)
        }
        // Нажатие - удалениеА
        row.setOnLongClickListener {
            showDeleteDialog(item)
            true
        }

        return row
    }

    // Диалог рдактирования названия товара
    private fun showEditDialog(item: ShoppingItem) {
        val dialog = AlertDialog.Builder(this)
        val input = EditText(this).apply {
            setText(item.name)
            hint = "Новое название"
        }

        dialog.setTitle("Редактировать товар")
            .setView(input)
            .setPositiveButton("Сохранить") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    db.updateItemName(item.id, newName)
                    refreshList()
                    Toast.makeText(this, "Товар обновлен", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    // Диалог подстверждения удаления
    private fun showDeleteDialog(item: ShoppingItem) {
        AlertDialog.Builder(this)
            .setTitle("Удаление товара")
            .setMessage("Удалить '${item.name}' из списка?")
            .setPositiveButton("Да") { _, _ ->
                db.deleteItem(item.id)
                refreshList()
                Toast.makeText(this, "Товар удален", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Нет", null)
            .show()
    }

    // Обновление прогресс-бара
    private fun updateBudgetProgress(spent: Double) {
        val percent = ((spent / budget) * 100).toInt()
        budgetProgress.progress = minOf(percent, 100)

        val color = android.graphics.Color.parseColor("#4CAF50")
        budgetProgress.progressTintList = android.content.res.ColorStateList.valueOf(color)

        budgetInfo.text = "Бюджет: ${currency.format(budget)} • Потрачено: ${currency.format(spent)} ($percent%)"
    }
}