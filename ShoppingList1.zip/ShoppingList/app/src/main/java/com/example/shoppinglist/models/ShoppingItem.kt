package com.example.shoppinglist.models

data class ShoppingItem(
    val id: Int,
    val categoryId: Int,
    val name: String,
    val price: Double = 0.0,
    var isPurchased: Boolean = false
)