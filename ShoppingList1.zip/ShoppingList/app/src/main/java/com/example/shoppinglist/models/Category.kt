package com.example.shoppinglist.models

data class Category(
    val id: Int,
    val name: String
)