package com.example.shoppinglist

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.example.shoppinglist.models.Category
import com.example.shoppinglist.models.ShoppingItem

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, "shopping.db", null, 3) {

    // Константы для названий таблиц и колонок
    companion object {
        private const val TABLE_CATEGORIES = "categories"
        private const val TABLE_ITEMS = "items"
        private const val COLUMN_ID = "id"
        private const val COLUMN_NAME = "name"
        private const val COLUMN_CATEGORY_ID = "category_id"
        private const val COLUMN_PRICE = "price"
        private const val COLUMN_IS_PURCHASED = "is_purchased"
    }

    // Создание таблиц и заполнение тестовыми данными
    override fun onCreate(db: SQLiteDatabase) {
        try {
            // Создание таблицы категорий
            db.execSQL("""
                CREATE TABLE $TABLE_CATEGORIES (
                    $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_NAME TEXT NOT NULL
                )
            """)

            // Создание таблицы товаров
            db.execSQL("""
                CREATE TABLE $TABLE_ITEMS (
                    $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    $COLUMN_CATEGORY_ID INTEGER NOT NULL,
                    $COLUMN_NAME TEXT NOT NULL,
                    $COLUMN_PRICE REAL DEFAULT 0.0,
                    $COLUMN_IS_PURCHASED INTEGER DEFAULT 0,
                    FOREIGN KEY($COLUMN_CATEGORY_ID) REFERENCES $TABLE_CATEGORIES($COLUMN_ID)
                )
            """)

            // Добавляем тестовые данные при первом запуске
            addTestData(db)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    // Добавление тестовых данных
    private fun addTestData(db: SQLiteDatabase) {
        // Добавляем категории
        val categories = listOf("🥛 Молочные", "🍞 Хлеб", "🥬 Овощи", "🍎 Фрукты", "🥩 Мясо")
        val categoryIds = mutableListOf<Long>()

        for (name in categories) {
            val values = ContentValues().apply { put(COLUMN_NAME, name) }
            val id = db.insert(TABLE_CATEGORIES, null, values)
            if (id > 0) {
                categoryIds.add(id)
            }
        }

        // Добавляем тестовые товары
        if (categoryIds.size >= 4) {
            val testItems = listOf(
                Triple("Молоко 3.2%", categoryIds[0], 85.0),
                Triple("Хлеб Черный", categoryIds[1], 45.0),
                Triple("Яблоки красные", categoryIds[3], 120.0)
            )

            for ((name, catId, price) in testItems) {
                val values = ContentValues().apply {
                    put(COLUMN_CATEGORY_ID, catId)
                    put(COLUMN_NAME, name)
                    put(COLUMN_PRICE, price)
                    put(COLUMN_IS_PURCHASED, 0)
                }
                db.insert(TABLE_ITEMS, null, values)
            }
        }
    }

    // Вызывается при обновлении версии БД
    override fun onUpgrade(db: SQLiteDatabase, old: Int, new: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ITEMS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CATEGORIES")
        onCreate(db)
    }

    // Получение всех категорий из бд
    fun getCategories(): List<Category> {
        val list = mutableListOf<Category>()
        val db = readableDatabase
        val cursor = db.query(TABLE_CATEGORIES, null, null, null, null, null, COLUMN_NAME)

        while (cursor.moveToNext()) {
            list.add(
                Category(
                    id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                    name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME))
                )
            )
        }
        cursor.close()
        return list
    }

    // Добавление новой категории
    fun addCategory(name: String): Long {
        val values = ContentValues().apply { put(COLUMN_NAME, name) }
        return writableDatabase.insert(TABLE_CATEGORIES, null, values)
    }

    // Добавление нового товара
    fun addItem(item: ShoppingItem): Long {
        val values = ContentValues().apply {
            put(COLUMN_CATEGORY_ID, item.categoryId)
            put(COLUMN_NAME, item.name)
            put(COLUMN_PRICE, item.price)
            put(COLUMN_IS_PURCHASED, if (item.isPurchased) 1 else 0)
        }
        return writableDatabase.insert(TABLE_ITEMS, null, values)
    }

    // Получение товаров сгруппированных по категории
    fun getItems(onlyNotPurchased: Boolean = false): Map<Category, List<ShoppingItem>> {
        val map = mutableMapOf<Category, MutableList<ShoppingItem>>()
        val db = readableDatabase

        // Условие для фильтра
        val filter = if (onlyNotPurchased) "WHERE i.$COLUMN_IS_PURCHASED = 0" else ""

        val query = """
            SELECT i.*, c.$COLUMN_NAME as category_name 
            FROM $TABLE_ITEMS i 
            JOIN $TABLE_CATEGORIES c ON i.$COLUMN_CATEGORY_ID = c.$COLUMN_ID 
            $filter
            ORDER BY c.$COLUMN_NAME, i.$COLUMN_NAME
        """

        val cursor = db.rawQuery(query, null)
        // Получение данных из таблиц
        while (cursor.moveToNext()) {
            // Создание объекта категории
            val category = Category(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_ID)),
                name = cursor.getString(cursor.getColumnIndexOrThrow("category_name"))
            )
            // Создание объекта товара
            val item = ShoppingItem(
                id = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                categoryId = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_CATEGORY_ID)),
                name = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NAME)),
                price = cursor.getDouble(cursor.getColumnIndexOrThrow(COLUMN_PRICE)),
                isPurchased = cursor.getInt(cursor.getColumnIndexOrThrow(COLUMN_IS_PURCHASED)) == 1
            )
            // Группировка товаров по категориям
            if (!map.containsKey(category)) {
                map[category] = mutableListOf()
            }
            map[category]?.add(item)
        }
        cursor.close()
        return map
    }

    // Обновление статуса покупки
    fun updateItem(itemId: Int, purchased: Boolean) {
        val values = ContentValues().apply {
            put(COLUMN_IS_PURCHASED, if (purchased) 1 else 0)
        }
        writableDatabase.update(
            TABLE_ITEMS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(itemId.toString())
        )
    }

    // Обновление названия товара (редактирование)
    fun updateItemName(itemId: Int, newName: String) {
        val values = ContentValues().apply { put(COLUMN_NAME, newName) }
        writableDatabase.update(
            TABLE_ITEMS,
            values,
            "$COLUMN_ID = ?",
            arrayOf(itemId.toString())
        )
    }

    // Удаление товара из БД
    fun deleteItem(itemId: Int) {
        writableDatabase.delete(
            TABLE_ITEMS,
            "$COLUMN_ID = ?",
            arrayOf(itemId.toString())
        )
    }
}